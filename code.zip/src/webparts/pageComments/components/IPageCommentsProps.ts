import { WebPartContext } from "@microsoft/sp-webpart-base";

export interface IPageCommentsProps {
  context: WebPartContext;
}
