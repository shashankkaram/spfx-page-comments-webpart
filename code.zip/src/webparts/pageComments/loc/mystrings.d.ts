declare interface IPageCommentsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'PageCommentsWebPartStrings' {
  const strings: IPageCommentsWebPartStrings;
  export = strings;
}
